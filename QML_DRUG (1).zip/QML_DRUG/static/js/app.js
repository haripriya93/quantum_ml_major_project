import { Chart } from "@/components/ui/chart"
/**
 * Quantum ML Drug Discovery Platform
 * Main JavaScript file
 */

// Global variables
let currentTab = "dashboard"
let currentPage = 1
const pageSize = 10
let totalPages = 1
let searchQuery = ""
let trainingInterval = null
let currentTrainingId = null
let trainingLossChart = null
const dashboardCharts = {}

// DOM Elements
document.addEventListener("DOMContentLoaded", () => {
  console.log("Initializing Quantum ML Drug Discovery Platform...")

  // Initialize background animation
  initBackgroundAnimation()

  // Initialize tabs
  initTabs()

  // Initialize dashboard
  loadDashboardData()

  // Initialize dataset
  setupDatasetControls()
  loadDatasetPage(1)

  // Initialize training
  setupTrainingForm()
  loadTrainedModels()

  // Initialize prediction
  setupPredictionForm()
  loadPredictionModels()

  // Initialize about page
  setupQuantumCircuitAnimation()

  // Initialize modal
  setupModal()

  console.log("Initialization complete.")
})

// Background Animation
function initBackgroundAnimation() {
  const canvas = document.getElementById("background-canvas")
  const ctx = canvas.getContext("2d")

  // Set canvas dimensions
  function resizeCanvas() {
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
  }

  resizeCanvas()
  window.addEventListener("resize", resizeCanvas)

  // Particle class
  class Particle {
    constructor() {
      this.x = Math.random() * canvas.width
      this.y = Math.random() * canvas.height
      this.size = Math.random() * 3 + 1
      this.speedX = Math.random() * 1 - 0.5
      this.speedY = Math.random() * 1 - 0.5
      this.color = `rgba(42, 157, 143, ${Math.random() * 0.5 + 0.1})`
    }

    update() {
      this.x += this.speedX
      this.y += this.speedY

      if (this.x < 0 || this.x > canvas.width) {
        this.speedX = -this.speedX
      }

      if (this.y < 0 || this.y > canvas.height) {
        this.speedY = -this.speedY
      }
    }

    draw() {
      ctx.fillStyle = this.color
      ctx.beginPath()
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  // Molecule class for background
  class Molecule {
    constructor() {
      this.x = Math.random() * canvas.width
      this.y = Math.random() * canvas.height
      this.size = Math.random() * 30 + 20
      this.speedX = Math.random() * 0.5 - 0.25
      this.speedY = Math.random() * 0.5 - 0.25
      this.atoms = Math.floor(Math.random() * 5) + 3
      this.rotation = 0
      this.rotationSpeed = Math.random() * 0.01 - 0.005
      this.color = `rgba(231, 111, 81, ${Math.random() * 0.3 + 0.1})`
    }

    update() {
      this.x += this.speedX
      this.y += this.speedY
      this.rotation += this.rotationSpeed

      if (this.x < 0 || this.x > canvas.width) {
        this.speedX = -this.speedX
      }

      if (this.y < 0 || this.y > canvas.height) {
        this.speedY = -this.speedY
      }
    }

    draw() {
      ctx.save()
      ctx.translate(this.x, this.y)
      ctx.rotate(this.rotation)

      // Draw bonds
      ctx.strokeStyle = this.color
      ctx.lineWidth = 2

      for (let i = 0; i < this.atoms; i++) {
        const angle1 = (i / this.atoms) * Math.PI * 2
        const x1 = Math.cos(angle1) * this.size
        const y1 = Math.sin(angle1) * this.size

        for (let j = i + 1; j < this.atoms; j++) {
          const angle2 = (j / this.atoms) * Math.PI * 2
          const x2 = Math.cos(angle2) * this.size
          const y2 = Math.sin(angle2) * this.size

          ctx.beginPath()
          ctx.moveTo(x1, y1)
          ctx.lineTo(x2, y2)
          ctx.stroke()
        }
      }

      // Draw atoms
      for (let i = 0; i < this.atoms; i++) {
        const angle = (i / this.atoms) * Math.PI * 2
        const x = Math.cos(angle) * this.size
        const y = Math.sin(angle) * this.size

        ctx.fillStyle = this.color
        ctx.beginPath()
        ctx.arc(x, y, 5, 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.restore()
    }
  }

  // Create particles and molecules
  const particles = []
  const molecules = []

  const particleCount = Math.min(100, Math.floor((canvas.width * canvas.height) / 10000))
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle())
  }

  const moleculeCount = Math.min(10, Math.floor((canvas.width * canvas.height) / 100000))
  for (let i = 0; i < moleculeCount; i++) {
    molecules.push(new Molecule())
  }

  // Animation loop
  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Update and draw particles
    particles.forEach((particle) => {
      particle.update()
      particle.draw()
    })

    // Update and draw molecules
    molecules.forEach((molecule) => {
      molecule.update()
      molecule.draw()
    })

    // Connect nearby particles
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x
        const dy = particles[i].y - particles[j].y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 100) {
          ctx.beginPath()
          ctx.strokeStyle = `rgba(42, 157, 143, ${0.1 * (1 - distance / 100)})`
          ctx.lineWidth = 1
          ctx.moveTo(particles[i].x, particles[i].y)
          ctx.lineTo(particles[j].x, particles[j].y)
          ctx.stroke()
        }
      }
    }

    requestAnimationFrame(animate)
  }

  animate()
  console.log("Background animation initialized.")
}

// Tab Navigation
function initTabs() {
  const tabs = document.querySelectorAll(".tab")
  const tabContents = document.querySelectorAll(".tab-content")

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const tabId = tab.getAttribute("data-tab")

      // Update active tab
      tabs.forEach((t) => t.classList.remove("active"))
      tab.classList.add("active")

      // Update active content
      tabContents.forEach((content) => {
        content.classList.remove("active")
        if (content.id === tabId) {
          content.classList.add("active")
        }
      })

      currentTab = tabId
      console.log(`Switched to ${tabId} tab`)

      // Refresh data when switching to tabs
      if (tabId === "dashboard") {
        loadDashboardData()
      } else if (tabId === "dataset") {
        loadDatasetPage(currentPage)
      } else if (tabId === "training") {
        loadTrainedModels()
      } else if (tabId === "prediction") {
        loadPredictionModels()
      }
    })
  })

  console.log("Tab navigation initialized.")
}

// Dashboard Functions
function loadDashboardData() {
  const loadingIndicator = document.createElement("div")
  loadingIndicator.className = "loading-indicator"
  loadingIndicator.innerHTML = '<div class="spinner"></div><p>Loading dashboard data...</p>'

  const dashboardSection = document.getElementById("dashboard")
  dashboardSection.appendChild(loadingIndicator)

  fetch("/api/dashboard/stats")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to load dashboard data")
      }
      return response.json()
    })
    .then((data) => {
      updateDashboardStats(data)
      createDashboardCharts(data)
      dashboardSection.removeChild(loadingIndicator)
    })
    .catch((error) => {
      console.error("Error loading dashboard data:", error)
      dashboardSection.removeChild(loadingIndicator)

      const errorMessage = document.createElement("div")
      errorMessage.className = "error-message"
      errorMessage.textContent = "Failed to load dashboard data. Please try again."
      dashboardSection.appendChild(errorMessage)

      setTimeout(() => {
        dashboardSection.removeChild(errorMessage)
      }, 3000)
    })

  // Set up refresh button
  document.getElementById("refresh-dashboard").addEventListener("click", loadDashboardData)

  console.log("Loading dashboard data...")
}

function updateDashboardStats(data) {
  document.getElementById("total-molecules").textContent = data.totalMolecules
  document.getElementById("avg-molecular-weight").textContent = data.avgMolecularWeight.toFixed(2)
  document.getElementById("avg-logp").textContent = data.avgLogP.toFixed(2)
  document.getElementById("avg-tpsa").textContent = data.avgTPSA.toFixed(2)

  console.log("Dashboard stats updated.")
}

function createDashboardCharts(data) {
  // Molecular Weight Distribution Chart
  const molWeightCtx = document.getElementById("molecular-weight-chart").getContext("2d")
  const molWeightData = data.distributions.MolecularWeight

  // Create histogram data
  const min = Math.min(...molWeightData)
  const max = Math.max(...molWeightData)
  const binCount = 10
  const binSize = (max - min) / binCount
  const bins = Array(binCount).fill(0)

  molWeightData.forEach((value) => {
    const binIndex = Math.min(Math.floor((value - min) / binSize), binCount - 1)
    bins[binIndex]++
  })

  const binLabels = Array(binCount)
    .fill(0)
    .map((_, i) => {
      const binStart = min + i * binSize
      return binStart.toFixed(0)
    })

  if (dashboardCharts.molWeightChart) {
    dashboardCharts.molWeightChart.destroy()
  }

  dashboardCharts.molWeightChart = new Chart(molWeightCtx, {
    type: "bar",
    data: {
      labels: binLabels,
      datasets: [
        {
          label: "Molecular Weight",
          data: bins,
          backgroundColor: "rgba(42, 157, 143, 0.7)",
          borderColor: "rgba(42, 157, 143, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
    },
  })

  // LogP Distribution Chart
  const logPCtx = document.getElementById("logp-chart").getContext("2d")
  const logPData = data.distributions.LogP

  // Create histogram data for LogP
  const logPMin = Math.min(...logPData)
  const logPMax = Math.max(...logPData)
  const logPBinCount = 10
  const logPBinSize = (logPMax - logPMin) / logPBinCount
  const logPBins = Array(logPBinCount).fill(0)

  logPData.forEach((value) => {
    const binIndex = Math.min(Math.floor((value - logPMin) / logPBinSize), logPBinCount - 1)
    logPBins[binIndex]++
  })

  const logPBinLabels = Array(logPBinCount)
    .fill(0)
    .map((_, i) => {
      const binStart = logPMin + i * logPBinSize
      return binStart.toFixed(1)
    })

  if (dashboardCharts.logPChart) {
    dashboardCharts.logPChart.destroy()
  }

  dashboardCharts.logPChart = new Chart(logPCtx, {
    type: "bar",
    data: {
      labels: logPBinLabels,
      datasets: [
        {
          label: "LogP",
          data: logPBins,
          backgroundColor: "rgba(231, 111, 81, 0.7)",
          borderColor: "rgba(231, 111, 81, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
    },
  })

  // Binding Affinity Distribution Chart
  const baCtx = document.getElementById("binding-affinity-chart").getContext("2d")
  const baData = data.distributions.BindingAffinity

  // Create histogram data for Binding Affinity
  const baMin = Math.min(...baData)
  const baMax = Math.max(...baData)
  const baBinCount = 10
  const baBinSize = (baMax - baMin) / baBinCount
  const baBins = Array(baBinCount).fill(0)

  baData.forEach((value) => {
    const binIndex = Math.min(Math.floor((value - baMin) / baBinSize), baBinCount - 1)
    baBins[binIndex]++
  })

  const baBinLabels = Array(baBinCount)
    .fill(0)
    .map((_, i) => {
      const binStart = baMin + i * baBinSize
      return binStart.toFixed(1)
    })

  if (dashboardCharts.baChart) {
    dashboardCharts.baChart.destroy()
  }

  dashboardCharts.baChart = new Chart(baCtx, {
    type: "bar",
    data: {
      labels: baBinLabels,
      datasets: [
        {
          label: "Binding Affinity",
          data: baBins,
          backgroundColor: "rgba(244, 162, 97, 0.7)",
          borderColor: "rgba(244, 162, 97, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
    },
  })

  // Property Correlations Chart
  const corrCtx = document.getElementById("correlation-chart").getContext("2d")

  // Create scatter data for MW vs LogP
  const scatterData = []
  for (let i = 0; i < molWeightData.length; i++) {
    scatterData.push({
      x: molWeightData[i],
      y: logPData[i],
    })
  }

  if (dashboardCharts.corrChart) {
    dashboardCharts.corrChart.destroy()
  }

  dashboardCharts.corrChart = new Chart(corrCtx, {
    type: "scatter",
    data: {
      datasets: [
        {
          label: "MW vs LogP",
          data: scatterData,
          backgroundColor: "rgba(42, 157, 143, 0.7)",
          borderColor: "rgba(42, 157, 143, 0.1)",
          pointRadius: 5,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
    },
  })

  console.log("Dashboard charts created.")
}

// Dataset Functions
function setupDatasetControls() {
  // Search button
  document.getElementById("search-btn").addEventListener("click", () => {
    searchQuery = document.getElementById("dataset-search").value.trim()
    loadDatasetPage(1)
  })

  // Reset search button
  document.getElementById("reset-search-btn").addEventListener("click", () => {
    document.getElementById("dataset-search").value = ""
    searchQuery = ""
    loadDatasetPage(1)
  })

  // Pagination buttons
  document.getElementById("prev-page").addEventListener("click", () => {
    if (currentPage > 1) {
      loadDatasetPage(currentPage - 1)
    }
  })

  document.getElementById("next-page").addEventListener("click", () => {
    if (currentPage < totalPages) {
      loadDatasetPage(currentPage + 1)
    }
  })

  // Enter key in search box
  document.getElementById("dataset-search").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      searchQuery = document.getElementById("dataset-search").value.trim()
      loadDatasetPage(1)
    }
  })

  console.log("Dataset controls initialized.")
}

function loadDatasetPage(page) {
  currentPage = page

  // Show loading indicator
  document.getElementById("loading-indicator").style.display = "flex"
  document.getElementById("no-data-message").style.display = "none"
  document.getElementById("dataset-table-body").innerHTML = ""

  // Disable pagination buttons during loading
  document.getElementById("prev-page").disabled = true
  document.getElementById("next-page").disabled = true

  // Build URL with query parameters
  const url = `/api/dataset?page=${page}&page_size=${pageSize}${searchQuery ? `&search=${encodeURIComponent(searchQuery)}` : ""}`

  fetch(url)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to load dataset")
      }
      return response.json()
    })
    .then((data) => {
      // Update pagination info
      totalPages = data.pagination.totalPages
      document.getElementById("page-info").textContent = `Page ${page} of ${totalPages}`

      // Enable/disable pagination buttons
      document.getElementById("prev-page").disabled = page <= 1
      document.getElementById("next-page").disabled = page >= totalPages

      // Hide loading indicator
      document.getElementById("loading-indicator").style.display = "none"

      // Check if there's data to display
      if (data.data.length === 0) {
        document.getElementById("no-data-message").style.display = "block"
      } else {
        // Populate table with data
        populateDatasetTable(data.data)
      }
    })
    .catch((error) => {
      console.error("Error loading dataset:", error)
      document.getElementById("loading-indicator").style.display = "none"
      document.getElementById("no-data-message").style.display = "block"
      document.getElementById("no-data-message").innerHTML = "<p>Error loading data. Please try again.</p>"
    })

  console.log(`Loading dataset page ${page}...`)
}

function populateDatasetTable(molecules) {
  const tableBody = document.getElementById("dataset-table-body")
  tableBody.innerHTML = ""

  molecules.forEach((molecule) => {
    const row = document.createElement("tr")

    // SMILES column
    const smilesCell = document.createElement("td")
    smilesCell.textContent = molecule.SMILES
    row.appendChild(smilesCell)

    // Structure column
    const structureCell = document.createElement("td")
    const structureImg = document.createElement("img")
    structureImg.className = "molecule-thumbnail"
    structureImg.alt = "Loading structure..."
    structureImg.src = "/static/img/loading.gif" // Placeholder
    structureCell.appendChild(structureImg)
    row.appendChild(structureCell)

    // Load molecule image
    fetch(`/api/molecule/image?smiles=${encodeURIComponent(molecule.SMILES)}`)
      .then((response) => response.json())
      .then((data) => {
        structureImg.src = data.image
        structureImg.alt = "Molecular structure"
      })
      .catch((error) => {
        console.error("Error loading molecule image:", error)
        structureImg.alt = "Error loading structure"
      })

    // Molecular Weight column
    const mwCell = document.createElement("td")
    mwCell.textContent = molecule.MolecularWeight.toFixed(2)
    row.appendChild(mwCell)

    // LogP column
    const logpCell = document.createElement("td")
    logpCell.textContent = molecule.LogP.toFixed(2)
    row.appendChild(logpCell)

    // TPSA column
    const tpsaCell = document.createElement("td")
    tpsaCell.textContent = molecule.TPSA.toFixed(2)
    row.appendChild(tpsaCell)

    // Binding Affinity column
    const baCell = document.createElement("td")
    baCell.textContent = molecule.BindingAffinity.toFixed(2)
    row.appendChild(baCell)

    // Actions column
    const actionsCell = document.createElement("td")
    actionsCell.className = "table-actions"

    const viewBtn = document.createElement("button")
    viewBtn.className = "btn action-btn"
    viewBtn.textContent = "View"
    viewBtn.addEventListener("click", () => showMoleculeDetails(molecule))
    actionsCell.appendChild(viewBtn)

    const predictBtn = document.createElement("button")
    predictBtn.className = "btn action-btn"
    predictBtn.textContent = "Predict"
    predictBtn.addEventListener("click", () => {
      // Switch to prediction tab and fill in SMILES
      document.querySelector('.tab[data-tab="prediction"]').click()
      document.getElementById("prediction-smiles").value = molecule.SMILES
    })
    actionsCell.appendChild(predictBtn)

    row.appendChild(actionsCell)

    tableBody.appendChild(row)
  })

  console.log(`Populated table with ${molecules.length} molecules.`)
}

function showMoleculeDetails(molecule) {
  const modal = document.getElementById("molecule-modal")
  const modalImage = document.getElementById("modal-molecule-image")
  const modalProperties = document.getElementById("modal-molecule-properties")

  // Clear previous content
  modalImage.innerHTML = ""
  modalProperties.innerHTML = ""

  // Load molecule image
  fetch(`/api/molecule/image?smiles=${encodeURIComponent(molecule.SMILES)}`)
    .then((response) => response.json())
    .then((data) => {
      const img = document.createElement("img")
      img.src = data.image
      img.alt = "Molecular structure"
      img.style.maxWidth = "100%"
      img.style.maxHeight = "100%"
      modalImage.appendChild(img)
    })
    .catch((error) => {
      console.error("Error loading molecule image:", error)
      modalImage.textContent = "Error loading structure"
    })

  // Add properties
  const properties = [
    { name: "SMILES", value: molecule.SMILES },
    { name: "Molecular Weight", value: molecule.MolecularWeight.toFixed(2) },
    { name: "LogP", value: molecule.LogP.toFixed(2) },
    { name: "TPSA", value: molecule.TPSA.toFixed(2) },
    { name: "H-Bond Donors", value: molecule.HBondDonors },
    { name: "H-Bond Acceptors", value: molecule.HBondAcceptors },
    { name: "Rotatable Bonds", value: molecule.RotatableBonds },
    { name: "Quantum Property 1", value: molecule.QuantumProperty1.toFixed(3) },
    { name: "Quantum Property 2", value: molecule.QuantumProperty2.toFixed(3) },
    { name: "Binding Affinity", value: molecule.BindingAffinity.toFixed(2) },
  ]

  properties.forEach((prop) => {
    const propDiv = document.createElement("div")
    propDiv.className = "property-item"

    const nameSpan = document.createElement("div")
    nameSpan.className = "property-name"
    nameSpan.textContent = prop.name

    const valueSpan = document.createElement("div")
    valueSpan.className = "property-value"
    valueSpan.textContent = prop.value

    propDiv.appendChild(nameSpan)
    propDiv.appendChild(valueSpan)
    modalProperties.appendChild(propDiv)
  })

  // Show modal
  modal.style.display = "block"

  console.log(`Showing details for molecule: ${molecule.SMILES}`)
}

function setupModal() {
  const modal = document.getElementById("molecule-modal")
  const closeBtn = document.querySelector(".close-modal")

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none"
  })

  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.style.display = "none"
    }
  })

  console.log("Modal initialized.")
}

// Training Functions
function setupTrainingForm() {
  const form = document.getElementById("training-form")
  const quantumDepth = document.getElementById("quantum-depth")
  const quantumDepthValue = document.getElementById("quantum-depth-value")
  const trainTestSplit = document.getElementById("train-test-split")
  const trainTestSplitValue = document.getElementById("train-test-split-value")

  // Update range input values
  quantumDepth.addEventListener("input", () => {
    quantumDepthValue.textContent = quantumDepth.value
  })

  trainTestSplit.addEventListener("input", () => {
    trainTestSplitValue.textContent = `${trainTestSplit.value}%`
  })

  // Form submission
  form.addEventListener("submit", (e) => {
    e.preventDefault()

    const trainingParams = {
      modelType: document.getElementById("model-type").value,
      targetProperty: document.getElementById("target-property").value,
      quantumDepth: Number.parseInt(quantumDepth.value),
      epochs: Number.parseInt(document.getElementById("training-epochs").value),
      batchSize: Number.parseInt(document.getElementById("batch-size").value),
      learningRate: Number.parseFloat(document.getElementById("learning-rate").value),
      trainTestSplit: Number.parseInt(trainTestSplit.value) / 100,
    }

    startTraining(trainingParams)
  })

  // Stop training button
  document.getElementById("stop-training-btn").addEventListener("click", stopTraining)

  console.log("Training form initialized.")
}

function startTraining(params) {
  console.log("Starting training with parameters:", params)

  // Show progress container and hide form
  document.querySelector(".training-form-container").style.display = "none"
  document.querySelector(".training-progress-container").style.display = "block"

  // Reset progress UI
  document.getElementById("training-progress-bar").style.width = "0%"
  document.getElementById("training-progress-percentage").textContent = "0%"
  document.getElementById("training-loss").textContent = "-"
  document.getElementById("training-accuracy").textContent = "-"
  document.getElementById("training-epochs-completed").textContent = "-"

  // Send training request to server
  fetch("/api/training/start", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(params),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to start training")
      }
      return response.json()
    })
    .then((data) => {
      currentTrainingId = data.trainingId

      // Start polling for training status
      if (trainingInterval) {
        clearInterval(trainingInterval)
      }

      trainingInterval = setInterval(checkTrainingStatus, 1000)

      console.log(`Training started with ID: ${currentTrainingId}`)
    })
    .catch((error) => {
      console.error("Error starting training:", error)
      alert("Failed to start training. Please try again.")

      // Show form again
      document.querySelector(".training-form-container").style.display = "block"
      document.querySelector(".training-progress-container").style.display = "none"
    })
}

function checkTrainingStatus() {
  if (!currentTrainingId) {
    return
  }

  fetch(`/api/training/status?trainingId=${currentTrainingId}`)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to get training status")
      }
      return response.json()
    })
    .then((data) => {
      updateTrainingProgress(data)

      if (data.status === "completed") {
        stopTraining()
        loadTrainedModels()
      }
    })
    .catch((error) => {
      console.error("Error checking training status:", error)
    })
}

function updateTrainingProgress(data) {
  // Update progress bar
  const progressBar = document.getElementById("training-progress-bar")
  const progressPercentage = document.getElementById("training-progress-percentage")

  progressBar.style.width = `${data.progress}%`
  progressPercentage.textContent = `${data.progress}%`

  // Update metrics
  document.getElementById("training-loss").textContent = data.metrics.loss.toFixed(4)
  document.getElementById("training-accuracy").textContent = `${(data.metrics.accuracy * 100).toFixed(2)}%`
  document.getElementById("training-epochs-completed").textContent = data.metrics.epochs

  // Update loss chart
  updateTrainingLossChart(data.history)

  console.log(`Training progress: ${data.progress}%`)
}

function updateTrainingLossChart(history) {
  const ctx = document.getElementById("training-loss-chart").getContext("2d")

  if (!trainingLossChart) {
    trainingLossChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: history.epochs,
        datasets: [
          {
            label: "Loss",
            data: history.loss,
            borderColor: "rgba(42, 157, 143, 1)",
            backgroundColor: "rgba(42, 157, 143, 0.1)",
            borderWidth: 2,
            fill: true,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      },
    })
  } else {
    trainingLossChart.data.labels = history.epochs
    trainingLossChart.data.datasets[0].data = history.loss
    trainingLossChart.update()
  }
}

function stopTraining() {
  if (trainingInterval) {
    clearInterval(trainingInterval)
    trainingInterval = null
  }

  // Show form again
  document.querySelector(".training-form-container").style.display = "block"
  document.querySelector(".training-progress-container").style.display = "none"

  console.log("Training stopped.")
}

function loadTrainedModels() {
  const modelsList = document.getElementById("trained-models-list")
  modelsList.innerHTML = '<div class="loading-indicator"><div class="spinner"></div><p>Loading models...</p></div>'

  fetch("/api/models")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to load models")
      }
      return response.json()
    })
    .then((models) => {
      modelsList.innerHTML = ""

      if (models.length === 0) {
        modelsList.innerHTML = "<p>No trained models available.</p>"
        return
      }

      models.forEach((model) => {
        const modelCard = document.createElement("div")
        modelCard.className = "model-card"

        const modelHeader = document.createElement("div")
        modelHeader.className = "model-header"

        const modelName = document.createElement("div")
        modelName.className = "model-name"
        modelName.textContent = model.name

        const modelAccuracy = document.createElement("div")
        modelAccuracy.className = "model-accuracy"
        modelAccuracy.textContent = `${(model.accuracy * 100).toFixed(1)}%`

        modelHeader.appendChild(modelName)
        modelHeader.appendChild(modelAccuracy)

        const modelInfo = document.createElement("div")
        modelInfo.className = "model-info"
        modelInfo.textContent = `Created: ${model.created}`

        const modelDescription = document.createElement("div")
        modelDescription.className = "model-description"
        modelDescription.textContent = model.description

        const modelActions = document.createElement("div")
        modelActions.className = "model-actions"

        const useModelBtn = document.createElement("button")
        useModelBtn.className = "btn"
        useModelBtn.textContent = "Use for Prediction"
        useModelBtn.addEventListener("click", () => {
          // Switch to prediction tab and select this model
          document.querySelector('.tab[data-tab="prediction"]').click()

          // Wait for models to load in prediction tab
          setTimeout(() => {
            const predictionModelSelect = document.getElementById("prediction-model")
            for (let i = 0; i < predictionModelSelect.options.length; i++) {
              if (predictionModelSelect.options[i].value === model.id) {
                predictionModelSelect.selectedIndex = i
                break
              }
            }
          }, 100)
        })

        modelActions.appendChild(useModelBtn)

        modelCard.appendChild(modelHeader)
        modelCard.appendChild(modelInfo)
        modelCard.appendChild(modelDescription)
        modelCard.appendChild(modelActions)

        modelsList.appendChild(modelCard)
      })

      console.log(`Loaded ${models.length} trained models.`)
    })
    .catch((error) => {
      console.error("Error loading models:", error)
      modelsList.innerHTML = "<p>Error loading models. Please try again.</p>"
    })
}

// Prediction Functions
function setupPredictionForm() {
  const form = document.getElementById("prediction-form")

  // Form submission
  form.addEventListener("submit", (e) => {
    e.preventDefault()

    const smiles = document.getElementById("prediction-smiles").value.trim()
    const modelId = document.getElementById("prediction-model").value

    if (!smiles) {
      alert("Please enter a SMILES string.")
      return
    }

    makePrediction(smiles, modelId)
  })

  // Example molecule button
  document.getElementById("example-molecule-btn").addEventListener("click", () => {
    document.getElementById("prediction-smiles").value = "CC(=O)OC1=CC=CC=C1C(=O)O" // Aspirin
  })

  // New prediction button
  document.getElementById("new-prediction-btn").addEventListener("click", () => {
    document.querySelector(".prediction-form-container").style.display = "block"
    document.querySelector(".prediction-results-container").style.display = "none"
  })

  console.log("Prediction form initialized.")
}

function loadPredictionModels() {
  const modelSelect = document.getElementById("prediction-model")
  modelSelect.innerHTML = '<option value="" disabled selected>Loading models...</option>'

  fetch("/api/models")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to load models")
      }
      return response.json()
    })
    .then((models) => {
      modelSelect.innerHTML = ""

      if (models.length === 0) {
        modelSelect.innerHTML = '<option value="" disabled selected>No models available</option>'
        return
      }

      models.forEach((model) => {
        const option = document.createElement("option")
        option.value = model.id
        option.textContent = `${model.name} (${(model.accuracy * 100).toFixed(1)}%)`
        modelSelect.appendChild(option)
      })

      // Select first model by default
      modelSelect.selectedIndex = 0

      console.log(`Loaded ${models.length} models for prediction.`)
    })
    .catch((error) => {
      console.error("Error loading models for prediction:", error)
      modelSelect.innerHTML = '<option value="" disabled selected>Error loading models</option>'
    })
}

function makePrediction(smiles, modelId) {
  console.log(`Making prediction for SMILES: ${smiles} using model: ${modelId}`)

  // Show loading in results container
  document.querySelector(".prediction-form-container").style.display = "none"
  document.querySelector(".prediction-results-container").style.display = "block"
  document.getElementById("prediction-molecule-image").innerHTML = '<div class="spinner"></div><p>Loading...</p>'
  document.getElementById("molecular-properties").innerHTML = ""
  document.getElementById("quantum-properties").innerHTML = ""
  document.getElementById("binding-affinity-prediction").textContent = "-"
  document.getElementById("confidence-value").textContent = "-"

  // Send prediction request
  fetch("/api/prediction", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      smiles: smiles,
      modelId: modelId,
    }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to make prediction")
      }
      return response.json()
    })
    .then((data) => {
      displayPredictionResults(data)
    })
    .catch((error) => {
      console.error("Error making prediction:", error)
      alert("Failed to make prediction. Please check the SMILES string and try again.")

      // Show form again
      document.querySelector(".prediction-form-container").style.display = "block"
      document.querySelector(".prediction-results-container").style.display = "none"
    })
}

function displayPredictionResults(data) {
  // Load molecule image
  fetch(`/api/molecule/image?smiles=${encodeURIComponent(data.smiles)}`)
    .then((response) => response.json())
    .then((imgData) => {
      const img = document.createElement("img")
      img.src = imgData.image
      img.alt = "Molecular structure"
      img.style.maxWidth = "100%"
      img.style.maxHeight = "100%"

      const imageContainer = document.getElementById("prediction-molecule-image")
      imageContainer.innerHTML = ""
      imageContainer.appendChild(img)
    })
    .catch((error) => {
      console.error("Error loading molecule image:", error)
      document.getElementById("prediction-molecule-image").innerHTML = "Error loading structure"
    })

  // Display molecular properties
  const molPropertiesContainer = document.getElementById("molecular-properties")
  molPropertiesContainer.innerHTML = ""

  const molProperties = [
    { name: "Molecular Weight", value: data.properties.MolecularWeight.toFixed(2) },
    { name: "LogP", value: data.properties.LogP.toFixed(2) },
    { name: "TPSA", value: data.properties.TPSA.toFixed(2) },
    { name: "H-Bond Donors", value: data.properties.HBondDonors },
    { name: "H-Bond Acceptors", value: data.properties.HBondAcceptors },
    { name: "Rotatable Bonds", value: data.properties.RotatableBonds },
  ]

  molProperties.forEach((prop) => {
    const propDiv = document.createElement("div")
    propDiv.className = "property-item"

    const nameSpan = document.createElement("div")
    nameSpan.className = "property-name"
    nameSpan.textContent = prop.name

    const valueSpan = document.createElement("div")
    valueSpan.className = "property-value"
    valueSpan.textContent = prop.value

    propDiv.appendChild(nameSpan)
    propDiv.appendChild(valueSpan)
    molPropertiesContainer.appendChild(propDiv)
  })

  // Display quantum properties
  const quantumPropertiesContainer = document.getElementById("quantum-properties")
  quantumPropertiesContainer.innerHTML = ""

  const quantumProperties = [
    { name: "Quantum Property 1", value: data.quantumProperties.QuantumProperty1.toFixed(3) },
    { name: "Quantum Property 2", value: data.quantumProperties.QuantumProperty2.toFixed(3) },
  ]

  quantumProperties.forEach((prop) => {
    const propDiv = document.createElement("div")
    propDiv.className = "property-item"

    const nameSpan = document.createElement("div")
    nameSpan.className = "property-name"
    nameSpan.textContent = prop.name

    const valueSpan = document.createElement("div")
    valueSpan.className = "property-value"
    valueSpan.textContent = prop.value

    propDiv.appendChild(nameSpan)
    propDiv.appendChild(valueSpan)
    quantumPropertiesContainer.appendChild(propDiv)
  })

  // Display prediction result
  document.getElementById("binding-affinity-prediction").textContent = data.prediction.BindingAffinity.toFixed(2)
  document.getElementById("confidence-value").textContent = `${(data.prediction.confidence * 100).toFixed(1)}%`

  console.log("Prediction results displayed.")
}

// About Page Functions
function setupQuantumCircuitAnimation() {
  const svg = document.getElementById("quantum-circuit-svg")

  if (!svg) {
    console.error("Quantum circuit SVG element not found")
    return
  }

  // Clear SVG
  while (svg.firstChild) {
    svg.removeChild(svg.firstChild)
  }

  // Set up quantum circuit visualization
  const qubits = 4
  const gates = 6
  const circuitWidth = 700
  const circuitHeight = 180
  const qubitSpacing = circuitHeight / (qubits + 1)
  const gateSpacing = circuitWidth / (gates + 1)

  // Draw qubit lines
  for (let i = 0; i < qubits; i++) {
    const y = (i + 1) * qubitSpacing

    const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
    line.setAttribute("x1", "50")
    line.setAttribute("y1", y)
    line.setAttribute("x2", circuitWidth - 50)
    line.setAttribute("y2", y)
    line.setAttribute("stroke", "#2a9d8f")
    line.setAttribute("stroke-width", "2")
    svg.appendChild(line)

    // Qubit label
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
    text.setAttribute("x", "30")
    text.setAttribute("y", y + 5)
    text.setAttribute("text-anchor", "end")
    text.setAttribute("font-family", "monospace")
    text.setAttribute("font-size", "14")
    text.setAttribute("fill", "#2a9d8f")
    text.textContent = `q${i}`
    svg.appendChild(text)
  }

  // Gate types
  const gateTypes = ["H", "X", "CNOT", "RY", "RZ", "SWAP"]

  // Draw gates
  for (let i = 0; i < gates; i++) {
    const x = (i + 1) * gateSpacing
    const gateType = gateTypes[i % gateTypes.length]

    if (gateType === "CNOT") {
      // Control qubit
      const controlQubit = i % qubits
      // Target qubit
      const targetQubit = (controlQubit + 1) % qubits

      const controlY = (controlQubit + 1) * qubitSpacing
      const targetY = (targetQubit + 1) * qubitSpacing

      // Control circle
      const controlCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      controlCircle.setAttribute("cx", x)
      controlCircle.setAttribute("cy", controlY)
      controlCircle.setAttribute("r", "5")
      controlCircle.setAttribute("fill", "#2a9d8f")
      svg.appendChild(controlCircle)

      // Connecting line
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
      line.setAttribute("x1", x)
      line.setAttribute("y1", controlY)
      line.setAttribute("x2", x)
      line.setAttribute("y2", targetY)
      line.setAttribute("stroke", "#2a9d8f")
      line.setAttribute("stroke-width", "2")
      svg.appendChild(line)

      // Target circle
      const targetCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      targetCircle.setAttribute("cx", x)
      targetCircle.setAttribute("cy", targetY)
      targetCircle.setAttribute("r", "10")
      targetCircle.setAttribute("fill", "white")
      targetCircle.setAttribute("stroke", "#2a9d8f")
      targetCircle.setAttribute("stroke-width", "2")
      svg.appendChild(targetCircle)

      // X symbol
      const xLine1 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      xLine1.setAttribute("x1", x - 5)
      xLine1.setAttribute("y1", targetY - 5)
      xLine1.setAttribute("x2", x + 5)
      xLine1.setAttribute("y2", targetY + 5)
      xLine1.setAttribute("stroke", "#2a9d8f")
      xLine1.setAttribute("stroke-width", "2")
      svg.appendChild(xLine1)

      const xLine2 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      xLine2.setAttribute("x1", x - 5)
      xLine2.setAttribute("y1", targetY + 5)
      xLine2.setAttribute("x2", x + 5)
      xLine2.setAttribute("y2", targetY - 5)
      xLine2.setAttribute("stroke", "#2a9d8f")
      xLine2.setAttribute("stroke-width", "2")
      svg.appendChild(xLine2)
    } else if (gateType === "SWAP") {
      // First qubit
      const qubit1 = i % qubits
      // Second qubit
      const qubit2 = (qubit1 + 2) % qubits

      const y1 = (qubit1 + 1) * qubitSpacing
      const y2 = (qubit2 + 1) * qubitSpacing

      // Connecting line
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
      line.setAttribute("x1", x)
      line.setAttribute("y1", y1)
      line.setAttribute("x2", x)
      line.setAttribute("y2", y2)
      line.setAttribute("stroke", "#2a9d8f")
      line.setAttribute("stroke-width", "2")
      svg.appendChild(line)

      // X symbol for first qubit
      const x1Line1 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      x1Line1.setAttribute("x1", x - 5)
      x1Line1.setAttribute("y1", y1 - 5)
      x1Line1.setAttribute("x2", x + 5)
      x1Line1.setAttribute("y2", y1 + 5)
      x1Line1.setAttribute("stroke", "#2a9d8f")
      x1Line1.setAttribute("stroke-width", "2")
      svg.appendChild(x1Line1)

      const x1Line2 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      x1Line2.setAttribute("x1", x - 5)
      x1Line2.setAttribute("y1", y1 + 5)
      x1Line2.setAttribute("x2", x + 5)
      x1Line2.setAttribute("y2", y1 - 5)
      x1Line2.setAttribute("stroke", "#2a9d8f")
      x1Line2.setAttribute("stroke-width", "2")
      svg.appendChild(x1Line2)

      // X symbol for second qubit
      const x2Line1 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      x2Line1.setAttribute("x1", x - 5)
      x2Line1.setAttribute("y1", y2 - 5)
      x2Line1.setAttribute("x2", x + 5)
      x2Line1.setAttribute("y2", y2 + 5)
      x2Line1.setAttribute("stroke", "#2a9d8f")
      \
            x2Line  y2 + 5)
      x2Line1.setAttribute("stroke", "#2a9d8f")
      x2Line1.setAttribute("stroke-width", "2")
      svg.appendChild(x2Line1)

      const x2Line2 = document.createElementNS("http://www.w3.org/2000/svg", "line")
      x2Line2.setAttribute("x1", x - 5)
      x2Line2.setAttribute("y1", y2 + 5)
      x2Line2.setAttribute("x2", x + 5)
      x2Line2.setAttribute("y2", y2 - 5)
      x2Line2.setAttribute("stroke", "#2a9d8f")
      x2Line2.setAttribute("stroke-width", "2")
      svg.appendChild(x2Line2)
    } else {
      // Single qubit gate
      const qubit = (i + Math.floor(i / 2)) % qubits
      const y = (qubit + 1) * qubitSpacing

      // Gate box
      const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect")
      rect.setAttribute("x", x - 15)
      rect.setAttribute("y", y - 15)
      rect.setAttribute("width", "30")
      rect.setAttribute("height", "30")
      rect.setAttribute("fill", "white")
      rect.setAttribute("stroke", "#2a9d8f")
      rect.setAttribute("stroke-width", "2")
      rect.setAttribute("rx", "4")
      svg.appendChild(rect)

      // Gate label
      const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
      text.setAttribute("x", x)
      text.setAttribute("y", y + 5)
      text.setAttribute("text-anchor", "middle")
      text.setAttribute("font-family", "monospace")
      text.setAttribute("font-size", "14")
      text.setAttribute("fill", "#2a9d8f")
      text.textContent = gateType
      svg.appendChild(text)
    }
  }

  // Add animation
  const animateCircuit = () => {
    const gates = svg.querySelectorAll("rect, circle")

    gates.forEach((gate, index) => {
      setTimeout(() => {
        gate.setAttribute("fill", "rgba(42, 157, 143, 0.3)")
        setTimeout(() => {
          gate.setAttribute("fill", "white")
        }, 300)
      }, index * 200)
    })

    setTimeout(animateCircuit, gates.length * 200 + 1000)
  }

  animateCircuit()

  console.log("Quantum circuit animation initialized.")
}
