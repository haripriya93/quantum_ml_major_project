/**
 * Simple Chart.js polyfill for creating basic charts
 * This is a lightweight implementation that provides basic charting functionality
 */
class Chart {
  constructor(canvas, config) {
    this.canvas = typeof canvas === "string" ? document.getElementById(canvas) : canvas
    this.ctx = this.canvas.getContext("2d")
    this.config = config
    this.data = config.data
    this.options = config.options || {}
    this.type = config.type
    this.colors = [
      "#2a9d8f",
      "#e76f51",
      "#f4a261",
      "#e9c46a",
      "#264653",
      "#52b788",
      "#ffb703",
      "#e63946",
      "#457b9d",
      "#1d3557",
    ]

    // Set canvas dimensions if not already set
    if (!this.canvas.style.width) {
      this.canvas.width = this.canvas.parentNode.clientWidth
    }
    if (!this.canvas.style.height) {
      this.canvas.height = this.canvas.parentNode.clientHeight || 300
    }

    this.render()
  }

  render() {
    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)

    // Choose chart type
    switch (this.type) {
      case "bar":
        this.drawBarChart()
        break
      case "line":
        this.drawLineChart()
        break
      case "scatter":
        this.drawScatterChart()
        break
      case "doughnut":
      case "pie":
        this.drawPieChart()
        break
      default:
        console.error("Unsupported chart type:", this.type)
    }
  }

  drawBarChart() {
    const { datasets, labels } = this.data
    const padding = 40
    const chartWidth = this.canvas.width - padding * 2
    const chartHeight = this.canvas.height - padding * 2
    const barCount = labels.length
    const datasetCount = datasets.length
    const barWidth = chartWidth / barCount / (datasetCount + 0.5)

    // Find max value for scaling
    let maxValue = 0
    datasets.forEach((dataset) => {
      const localMax = Math.max(...dataset.data)
      maxValue = Math.max(maxValue, localMax)
    })

    // Add 10% padding to max value
    maxValue *= 1.1

    // Draw axes
    this.ctx.beginPath()
    this.ctx.moveTo(padding, padding)
    this.ctx.lineTo(padding, this.canvas.height - padding)
    this.ctx.lineTo(this.canvas.width - padding, this.canvas.height - padding)
    this.ctx.strokeStyle = "#ccc"
    this.ctx.stroke()

    // Draw y-axis labels
    this.ctx.textAlign = "right"
    this.ctx.textBaseline = "middle"
    this.ctx.fillStyle = "#666"
    this.ctx.font = "12px Arial"

    for (let i = 0; i <= 5; i++) {
      const value = maxValue * (i / 5)
      const y = this.canvas.height - padding - chartHeight * (i / 5)
      this.ctx.fillText(value.toFixed(1), padding - 5, y)

      // Draw horizontal grid line
      this.ctx.beginPath()
      this.ctx.moveTo(padding, y)
      this.ctx.lineTo(this.canvas.width - padding, y)
      this.ctx.strokeStyle = "#eee"
      this.ctx.stroke()
    }

    // Draw bars and x-axis labels
    this.ctx.textAlign = "center"
    this.ctx.textBaseline = "top"

    labels.forEach((label, i) => {
      const x = padding + (i * chartWidth) / barCount + barWidth / 2

      // Draw x-axis label
      this.ctx.fillText(label, x + (barWidth * datasetCount) / 2, this.canvas.height - padding + 5)

      // Draw bars for each dataset
      datasets.forEach((dataset, j) => {
        const value = dataset.data[i] || 0
        const barHeight = (value / maxValue) * chartHeight
        const barX = x + j * barWidth

        // Draw bar
        this.ctx.fillStyle = dataset.backgroundColor || this.colors[j % this.colors.length]
        this.ctx.fillRect(barX, this.canvas.height - padding - barHeight, barWidth * 0.8, barHeight)

        // Draw bar border
        this.ctx.strokeStyle = dataset.borderColor || "rgba(0,0,0,0.1)"
        this.ctx.strokeRect(barX, this.canvas.height - padding - barHeight, barWidth * 0.8, barHeight)
      })
    })

    // Draw legend if multiple datasets
    if (datasetCount > 1) {
      this.drawLegend(datasets)
    }
  }

  drawLineChart() {
    const { datasets, labels } = this.data
    const padding = 40
    const chartWidth = this.canvas.width - padding * 2
    const chartHeight = this.canvas.height - padding * 2
    const pointCount = labels.length

    // Find max value for scaling
    let maxValue = 0
    datasets.forEach((dataset) => {
      const localMax = Math.max(...dataset.data)
      maxValue = Math.max(maxValue, localMax)
    })

    // Add 10% padding to max value
    maxValue *= 1.1

    // Draw axes
    this.ctx.beginPath()
    this.ctx.moveTo(padding, padding)
    this.ctx.lineTo(padding, this.canvas.height - padding)
    this.ctx.lineTo(this.canvas.width - padding, this.canvas.height - padding)
    this.ctx.strokeStyle = "#ccc"
    this.ctx.stroke()

    // Draw y-axis labels
    this.ctx.textAlign = "right"
    this.ctx.textBaseline = "middle"
    this.ctx.fillStyle = "#666"
    this.ctx.font = "12px Arial"

    for (let i = 0; i <= 5; i++) {
      const value = maxValue * (i / 5)
      const y = this.canvas.height - padding - chartHeight * (i / 5)
      this.ctx.fillText(value.toFixed(1), padding - 5, y)

      // Draw horizontal grid line
      this.ctx.beginPath()
      this.ctx.moveTo(padding, y)
      this.ctx.lineTo(this.canvas.width - padding, y)
      this.ctx.strokeStyle = "#eee"
      this.ctx.stroke()
    }

    // Draw x-axis labels
    this.ctx.textAlign = "center"
    this.ctx.textBaseline = "top"

    labels.forEach((label, i) => {
      const x = padding + (i * chartWidth) / (pointCount - 1)
      this.ctx.fillText(label, x, this.canvas.height - padding + 5)
    })

    // Draw lines and points
    datasets.forEach((dataset, datasetIndex) => {
      const color = dataset.borderColor || this.colors[datasetIndex % this.colors.length]
      const pointColor = dataset.pointBackgroundColor || color
      const pointBorderColor = dataset.pointBorderColor || "#fff"
      const pointRadius = dataset.pointRadius || 4

      // Draw line
      this.ctx.beginPath()
      dataset.data.forEach((value, i) => {
        const x = padding + (i * chartWidth) / (pointCount - 1)
        const y = this.canvas.height - padding - (value / maxValue) * chartHeight

        if (i === 0) {
          this.ctx.moveTo(x, y)
        } else {
          this.ctx.lineTo(x, y)
        }
      })
      this.ctx.strokeStyle = color
      this.ctx.lineWidth = dataset.borderWidth || 2
      this.ctx.stroke()

      // Draw points
      dataset.data.forEach((value, i) => {
        const x = padding + (i * chartWidth) / (pointCount - 1)
        const y = this.canvas.height - padding - (value / maxValue) * chartHeight

        this.ctx.beginPath()
        this.ctx.arc(x, y, pointRadius, 0, Math.PI * 2)
        this.ctx.fillStyle = pointColor
        this.ctx.fill()
        this.ctx.strokeStyle = pointBorderColor
        this.ctx.lineWidth = 1
        this.ctx.stroke()
      })
    })

    // Draw legend if multiple datasets
    if (datasets.length > 1) {
      this.drawLegend(datasets)
    }
  }

  drawScatterChart() {
    const { datasets } = this.data
    const padding = 40
    const chartWidth = this.canvas.width - padding * 2
    const chartHeight = this.canvas.height - padding * 2

    // Find max values for scaling
    let maxX = 0
    let maxY = 0

    datasets.forEach((dataset) => {
      dataset.data.forEach((point) => {
        maxX = Math.max(maxX, point.x)
        maxY = Math.max(maxY, point.y)
      })
    })

    // Add 10% padding to max values
    maxX *= 1.1
    maxY *= 1.1

    // Draw axes
    this.ctx.beginPath()
    this.ctx.moveTo(padding, padding)
    this.ctx.lineTo(padding, this.canvas.height - padding)
    this.ctx.lineTo(this.canvas.width - padding, this.canvas.height - padding)
    this.ctx.strokeStyle = "#ccc"
    this.ctx.stroke()

    // Draw y-axis labels
    this.ctx.textAlign = "right"
    this.ctx.textBaseline = "middle"
    this.ctx.fillStyle = "#666"
    this.ctx.font = "12px Arial"

    for (let i = 0; i <= 5; i++) {
      const value = maxY * (i / 5)
      const y = this.canvas.height - padding - chartHeight * (i / 5)
      this.ctx.fillText(value.toFixed(1), padding - 5, y)

      // Draw horizontal grid line
      this.ctx.beginPath()
      this.ctx.moveTo(padding, y)
      this.ctx.lineTo(this.canvas.width - padding, y)
      this.ctx.strokeStyle = "#eee"
      this.ctx.stroke()
    }

    // Draw x-axis labels
    this.ctx.textAlign = "center"
    this.ctx.textBaseline = "top"

    for (let i = 0; i <= 5; i++) {
      const value = maxX * (i / 5)
      const x = padding + chartWidth * (i / 5)
      this.ctx.fillText(value.toFixed(1), x, this.canvas.height - padding + 5)

      // Draw vertical grid line
      this.ctx.beginPath()
      this.ctx.moveTo(x, padding)
      this.ctx.lineTo(x, this.canvas.height - padding)
      this.ctx.strokeStyle = "#eee"
      this.ctx.stroke()
    }

    // Draw points
    datasets.forEach((dataset, datasetIndex) => {
      const color = dataset.backgroundColor || this.colors[datasetIndex % this.colors.length]
      const borderColor = dataset.borderColor || "#fff"
      const pointRadius = dataset.pointRadius || 6

      dataset.data.forEach((point) => {
        const x = padding + (point.x / maxX) * chartWidth
        const y = this.canvas.height - padding - (point.y / maxY) * chartHeight

        this.ctx.beginPath()
        this.ctx.arc(x, y, pointRadius, 0, Math.PI * 2)
        this.ctx.fillStyle = color
        this.ctx.fill()
        this.ctx.strokeStyle = borderColor
        this.ctx.lineWidth = 1
        this.ctx.stroke()
      })
    })

    // Draw legend if multiple datasets
    if (datasets.length > 1) {
      this.drawLegend(datasets)
    }
  }

  drawPieChart() {
    const { datasets, labels } = this.data
    const dataset = datasets[0]
    const centerX = this.canvas.width / 2
    const centerY = this.canvas.height / 2
    const radius = Math.min(centerX, centerY) - 40

    let total = 0
    dataset.data.forEach((value) => {
      total += value
    })

    let startAngle = -Math.PI / 2

    // Draw slices
    dataset.data.forEach((value, i) => {
      const sliceAngle = (value / total) * (Math.PI * 2)
      const endAngle = startAngle + sliceAngle
      const color =
        dataset.backgroundColor && dataset.backgroundColor[i]
          ? dataset.backgroundColor[i]
          : this.colors[i % this.colors.length]

      this.ctx.beginPath()
      this.ctx.moveTo(centerX, centerY)
      this.ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      this.ctx.closePath()
      this.ctx.fillStyle = color
      this.ctx.fill()
      this.ctx.strokeStyle = "#fff"
      this.ctx.lineWidth = 2
      this.ctx.stroke()

      startAngle = endAngle
    })

    // Draw legend
    this.drawLegend(datasets, labels)
  }

  drawLegend(datasets, customLabels = null) {
    const padding = 10
    const lineHeight = 20
    const legendWidth = 200
    const legendX = this.canvas.width - legendWidth - padding
    const legendY = padding

    // Draw legend background
    this.ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
    this.ctx.fillRect(legendX, legendY, legendWidth, datasets.length * lineHeight + padding * 2)
    this.ctx.strokeStyle = "#ccc"
    this.ctx.strokeRect(legendX, legendY, legendWidth, datasets.length * lineHeight + padding * 2)

    // Draw legend items
    datasets.forEach((dataset, i) => {
      const itemY = legendY + padding + i * lineHeight
      const color = dataset.backgroundColor || this.colors[i % this.colors.length]

      // Draw color box
      this.ctx.fillStyle = Array.isArray(color) ? color[0] : color
      this.ctx.fillRect(legendX + padding, itemY, 15, 15)
      this.ctx.strokeStyle = "#ccc"
      this.ctx.strokeRect(legendX + padding, itemY, 15, 15)

      // Draw label
      this.ctx.fillStyle = "#333"
      this.ctx.textAlign = "left"
      this.ctx.textBaseline = "middle"
      this.ctx.font = "12px Arial"

      const label = customLabels ? customLabels[i] : dataset.label || `Dataset ${i + 1}`
      this.ctx.fillText(label, legendX + padding + 20, itemY + 7.5)
    })
  }

  update() {
    this.render()
  }

  // Static method to create a new chart
  static createChart(canvas, config) {
    return new Chart(canvas, config)
  }
}

// Global Chart object
window.Chart = Chart
